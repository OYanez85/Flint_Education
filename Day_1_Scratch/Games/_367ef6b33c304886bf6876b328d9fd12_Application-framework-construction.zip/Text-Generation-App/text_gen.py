import os
from azure.ai.inference import ChatCompletionsClient
from azure.ai.inference.models import SystemMessage, UserMessage
from azure.core.credentials import AzureKeyCredential
from dotenv import load_dotenv
load_dotenv()


client = ChatCompletionsClient(
    endpoint=os.getenv("endpoint"),
    credential=AzureKeyCredential(os.getenv("api_key")),
    api_version="2024-05-01-preview"
)
model_name = "mistral-small-2503"

response = client.complete(
    messages=[
        SystemMessage(content=""),
        UserMessage(content=""),
    ],
    model=model_name
    )

print(response.choices[0].message.content)
